import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class CopyAndSave {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        CodecPolicy cp = new CodecPolicy();
        try {
            cp.signIN(driver);
            cp.configuration(driver);
            boolean success = cp.addPolicy(driver,"policy1","AMR","G729");
            assert success;
            cp.copySaveWithNewName(driver,"Policy6");
            System.out.println("Element is  copied");
            }
//            catch (StaleElementReferenceException e) {
//                 System.out.println(e);
//             }
        catch (InterruptedException e) {
            System.out.println(e);
            }
        finally {
           cp.cleanUp(driver);
           cp.logOut(driver);
            }
    }
}














import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;

public class AddMultipleDelete {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
        CodecPolicy cp = new CodecPolicy();
        try {
            cp.signIN(driver);
            cp.configuration(driver);
            cp.addMultiplePolicies(driver, "policy name", "AMR", "G729", 5);
            boolean deleteAll = cp.deleteAllCodecPolicies(driver);
            assert deleteAll;
        }
        catch (InterruptedException e) {
            System.out.println(e);
        }
        finally {
            cp.logOut(driver);
        }

    }
}

